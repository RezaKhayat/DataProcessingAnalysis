// This program will compile particle parameters from a Sparx refinement
// and CTF estimations from another file into a single file for Frealign
// refinement.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main (int argc, char *argv[])
{
        /* Local Definitions */
        int size1=0;
        int size2=0;
        int size3=0;
        int row=0;
        int row2=0;
        int image;
        char crap1[100];
        char crap2[100]; 
        char crap3[100];
        FILE *fpDataR1;
        FILE *fpDataR2;
        FILE *fpDataR3;
        FILE *fpDataW1;
        float phi, theta, psi, sx, sy, def1, def2, anagast, inplane, shx, shy;

        /* Statement */
        if ( argc != 4 )        // 0=program 1=Sparx Params 2=CTF estimation 3=keeplist 4=output
        {
                printf ("SparxToFrealign.exe <SparxParams> <CTF estimation>  <output-frealign input> \n");
                printf ("The CTF values must have Def1 Def2 and Anagast.\n"), exit (100);
        }
        else
        {
                printf("reading parameters and CTFs:");
                fpDataR1=fopen(argv[1], "r");
                fpDataR2=fopen(argv[2], "r");
                fpDataW1=fopen(argv[3], "W");

                while (fgets (crap1, 100, fpDataR1) != NULL)
                {
                        size1++;
                }
                while (fgets (crap2, 100, fpDataR2) != NULL)
                {
                        size2++;
                }

                printf ("There are %d parameters for particles and %d CTF values. \n", size1, size2);
        }

        if ( size1 == size2 )
        {
                printf("Both are equivalent and program will continue \n");
                fpDataR1=fopen(argv[1], "r");
                fpDataR2=fopen(argv[2], "r");
                fpDataW1=fopen(argv[3], "w");

                if (fpDataR1==NULL)
                {
                        printf("Could not locate the Parameter file! Try again. \n"), exit (100);
                }
                if (fpDataR2==NULL)
                {
                        printf("Could not locate the CTF file! Try again. \n"), exit (100);
                }

                fpDataR1=fopen(argv[1], "r");
                fpDataR2=fopen(argv[2], "r");

                for (row=1; row <= size1; row++)   // Read data in
                {
                        fscanf(fpDataR1, "%f %f %f %f %f", &phi, &theta, &psi, &sx, &sy);
                        fscanf(fpDataR2, "%f %f %f", &def1, &def2, &anagast);
                        inplane = psi; // NOT SURE ABOUT THIS
                        shx = -1*sx;
                        shy = -1*sy;

                        fprintf(fpDataW1, "%d 12 %8.2f %8.2f %8.2f %8.2f %8.2f 100000 1 %8.2f %8.2f %8.2f 50.00 50.00 \n", row, inplane, theta, phi, shx, shy, def1, def2, anagast);
                }
        }
        return 0;
}
